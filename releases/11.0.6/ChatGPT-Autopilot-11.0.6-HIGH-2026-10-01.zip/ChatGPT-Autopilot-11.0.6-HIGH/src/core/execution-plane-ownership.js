import { AgentExecutionPlane } from './agent-plan.js';
import { VerificationStatus, normalizeArtifactRefV1, normalizeVerificationV1 } from './universal-agent-contracts.js';

export const EXECUTION_OWNERSHIP_VERSION = 1;
export const ExecutionOwnershipState = Object.freeze({
  AVAILABLE: 'AVAILABLE',
  OWNED: 'OWNED',
  HANDOFF_PENDING: 'HANDOFF_PENDING',
  RECONCILE: 'RECONCILE',
  VERIFIED: 'VERIFIED',
  MANUAL_REVIEW: 'MANUAL_REVIEW',
});

const PLANES = new Set([AgentExecutionPlane.LOCAL, AgentExecutionPlane.CLOUD, AgentExecutionPlane.REMOTE]);
const STATES = new Set(Object.values(ExecutionOwnershipState));
const ID = /^[A-Za-z0-9][A-Za-z0-9._:@/+~-]{0,179}$/u;
const MAX_LEASE_MS = 24 * 60 * 60 * 1000;
export const TrustedExecutionVerificationOutcome = Object.freeze({
  EFFECT_VERIFIED: 'EFFECT_VERIFIED',
  NO_EFFECT_VERIFIED: 'NO_EFFECT_VERIFIED',
});
const TRUSTED_OUTCOMES = new Set(Object.values(TrustedExecutionVerificationOutcome));
const TRUSTED_RECORD_KEYS = new Set([
  'schemaVersion', 'recordId', 'taskId', 'planId', 'nodeId', 'effectId',
  'policyEnvelopeId', 'executionId', 'outcome', 'verification',
  'evidenceArtifacts', 'recordedAt', 'validThrough',
]);
const TRUSTED_REQUEST_KEYS = new Set(['leaseId', 'verificationId', 'at']);

function obj(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${label} must be a plain object`);
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) throw new Error(`${label} must be a plain object`);
  const output = Object.create(null);
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== 'string') throw new Error(`${label} contains symbol fields`);
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !('value' in descriptor) || descriptor.enumerable !== true) {
      throw new Error(`${label}.${key} must be an enumerable data property`);
    }
    output[key] = descriptor.value;
  }
  return output;
}
function exact(raw, allowed, label) { for (const key of Object.keys(raw)) if (!allowed.has(key)) throw new Error(`${label} contains unknown field: ${key}`); }
function id(value, label) { if (typeof value !== 'string' || value !== value.trim() || !ID.test(value)) throw new Error(`${label} is invalid`); return value; }
function ts(value, label) {
  if (typeof value !== 'string' || value !== value.trim() || !value) throw new Error(`${label} must be a timestamp`);
  const ms = Date.parse(value);
  if (!Number.isFinite(ms) || new Date(ms).toISOString() !== value) {
    throw new Error(`${label} must use canonical ISO-8601 UTC representation`);
  }
  return value;
}
function plane(value) { if (typeof value !== 'string' || value !== value.trim() || !PLANES.has(value)) throw new Error('execution plane is invalid'); return value; }
function optionalId(value, label) { return value == null || value === '' ? '' : id(value, label); }
function optionalTs(value, label) { return value == null || value === '' ? '' : ts(value, label); }
function optionalPlane(value) { return value == null || value === '' ? '' : plane(value); }
function boundedText(value, label, max = 1000) { if (typeof value !== 'string' || value !== value.trim() || !value || value.length > max) throw new Error(`${label} is invalid`); return value; }
function optionalBoundedText(value, label, max = 1000) { return value == null || value === '' ? '' : boundedText(value, label, max); }
function freeze(value) { if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value; for (const child of Object.values(value)) freeze(child); return Object.freeze(value); }

function dataArray(value, label, max = 128) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) {
    throw new Error(`${label} must be a bounded plain array`);
  }
  const descriptors = Object.getOwnPropertyDescriptors(value);
  const length = descriptors.length?.value;
  if (!Number.isSafeInteger(length) || length < 0 || length > max) {
    throw new Error(`${label} must be a bounded plain array`);
  }
  const expected = new Set(['length', ...Array.from({ length }, (_, index) => String(index))]);
  for (const key of Reflect.ownKeys(descriptors)) {
    if (typeof key !== 'string' || !expected.has(key)) {
      throw new Error(`${label} contains non-canonical array fields`);
    }
  }
  const output = new Array(length);
  for (let index = 0; index < length; index += 1) {
    const descriptor = descriptors[String(index)];
    if (!descriptor || descriptor.enumerable !== true || !Object.hasOwn(descriptor, 'value')) {
      throw new Error(`${label}[${index}] must be an enumerable own data property`);
    }
    output[index] = descriptor.value;
  }
  return output;
}

function sameIds(actual, expected, label) {
  const left = [...actual].sort();
  const right = [...expected].sort();
  if (left.length !== right.length || left.some((value, index) => value !== right[index])) {
    throw new Error(`${label} must exactly match trusted evidence identity`);
  }
}

export function normalizeTrustedExecutionVerificationRecordV1(input) {
  const raw = obj(input, 'TrustedExecutionVerificationRecordV1');
  exact(raw, TRUSTED_RECORD_KEYS, 'TrustedExecutionVerificationRecordV1');
  if (raw.schemaVersion !== EXECUTION_OWNERSHIP_VERSION) {
    throw new Error('Unsupported TrustedExecutionVerificationRecordV1 schemaVersion');
  }
  if (typeof raw.outcome !== 'string' || raw.outcome !== raw.outcome.trim() || !TRUSTED_OUTCOMES.has(raw.outcome)) {
    throw new Error('Trusted execution verification outcome is invalid');
  }
  const verification = normalizeVerificationV1(raw.verification);
  if (verification.status !== VerificationStatus.VERIFIED) {
    throw new Error('Trusted execution verification must have VERIFIED status');
  }
  const evidenceArtifacts = dataArray(raw.evidenceArtifacts, 'Trusted execution evidenceArtifacts')
    .map(normalizeArtifactRefV1);
  if (!evidenceArtifacts.length || !verification.evidenceArtifactIds.length) {
    throw new Error('Trusted execution verification requires hashed evidence artifacts');
  }
  if (new Set(evidenceArtifacts.map(item => item.artifactId)).size !== evidenceArtifacts.length) {
    throw new Error('Trusted execution verification contains duplicate evidence artifactId');
  }
  for (const artifact of evidenceArtifacts) {
    if (!artifact.sha256) throw new Error(`Trusted execution evidence artifact requires sha256: ${artifact.artifactId}`);
  }
  sameIds(
    evidenceArtifacts.map(item => item.artifactId),
    verification.evidenceArtifactIds,
    'Trusted execution verification evidenceArtifactIds',
  );
  return freeze({
    schemaVersion: EXECUTION_OWNERSHIP_VERSION,
    recordId: id(raw.recordId, 'trusted recordId'),
    taskId: id(raw.taskId, 'trusted taskId'),
    planId: id(raw.planId, 'trusted planId'),
    nodeId: id(raw.nodeId, 'trusted nodeId'),
    effectId: id(raw.effectId, 'trusted effectId'),
    policyEnvelopeId: id(raw.policyEnvelopeId, 'trusted policyEnvelopeId'),
    executionId: id(raw.executionId, 'trusted executionId'),
    outcome: raw.outcome,
    verification,
    evidenceArtifacts,
    recordedAt: ts(raw.recordedAt, 'trusted recordedAt'),
    validThrough: ts(raw.validThrough, 'trusted validThrough'),
  });
}

async function resolveTrustedExecutionVerificationV1(current, rawOptions, dependencies, expectedOutcome) {
  const request = obj(rawOptions, 'Trusted execution verification request');
  exact(request, TRUSTED_REQUEST_KEYS, 'Trusted execution verification request');
  const leaseId = id(request.leaseId, 'leaseId');
  const verificationId = id(request.verificationId, 'verificationId');
  const at = request.at === undefined ? new Date().toISOString() : ts(request.at, 'at');
  if (current.leaseId !== leaseId) throw new Error('trusted verification execution lease identity mismatch');
  const resolver = dependencies?.resolveTrustedExecutionVerificationRecord;
  if (typeof resolver !== 'function') throw new Error('canonical trusted execution verification resolver is required');
  const lookup = freeze({
    taskId: current.taskId,
    planId: current.planId,
    nodeId: current.nodeId,
    effectId: current.effectId,
    policyEnvelopeId: current.policyEnvelopeId,
    executionId: current.leaseId,
    verificationId,
    expectedOutcome,
  });
  const rawRecord = await resolver(lookup);
  if (rawRecord == null) throw new Error('trusted execution verification record was not found');
  const record = normalizeTrustedExecutionVerificationRecordV1(rawRecord);
  if (record.taskId !== current.taskId
      || record.planId !== current.planId
      || record.nodeId !== current.nodeId
      || record.effectId !== current.effectId
      || record.policyEnvelopeId !== current.policyEnvelopeId
      || record.executionId !== current.leaseId) {
    throw new Error('trusted execution verification record identity does not match durable ownership');
  }
  if (record.outcome !== expectedOutcome) throw new Error('trusted execution verification outcome does not match requested transition');
  const verification = record.verification;
  if (verification.verificationId !== verificationId) throw new Error('trusted execution verificationId mismatch');
  if (verification.effectId !== current.effectId || verification.executionId !== current.leaseId) {
    throw new Error('trusted VerificationV1 effect/execution binding mismatch');
  }
  if (verification.verificationAuthorityId !== current.policyEnvelopeId) {
    throw new Error('trusted VerificationV1 authority does not match execution policy envelope');
  }
  if (!verification.verifierId || verification.verifierId === current.ownerId) {
    throw new Error('trusted execution verification requires an independent verifier');
  }
  const verifiedAt = ts(verification.verifiedAt, 'trusted verifiedAt');
  if (Date.parse(verifiedAt) < Date.parse(current.updatedAt) || Date.parse(verifiedAt) > Date.parse(at)) {
    throw new Error('trusted execution verification chronology is invalid');
  }
  if (Date.parse(record.recordedAt) < Date.parse(verifiedAt) || Date.parse(record.recordedAt) > Date.parse(at)) {
    throw new Error('trusted execution verification record chronology is invalid');
  }
  if (Date.parse(record.validThrough) < Date.parse(record.recordedAt) || Date.parse(at) > Date.parse(record.validThrough)) {
    throw new Error('trusted execution verification record is stale');
  }
  for (const artifact of record.evidenceArtifacts) {
    const createdAt = ts(artifact.createdAt, 'trusted evidence createdAt');
    if (Date.parse(createdAt) < Date.parse(current.updatedAt)
        || Date.parse(createdAt) > Date.parse(verifiedAt)) {
      throw new Error(`trusted execution evidence chronology is invalid: ${artifact.artifactId}`);
    }
  }
  return freeze({ record, lookup, evaluatedAt: at });
}

export function createExecutionOwnershipV1({ taskId, planId, nodeId, effectId, policyEnvelopeId, at = new Date().toISOString() } = {}) {
  return normalizeExecutionOwnershipV1({
    schemaVersion: EXECUTION_OWNERSHIP_VERSION,
    taskId, planId, nodeId, effectId, policyEnvelopeId,
    state: ExecutionOwnershipState.AVAILABLE,
    ownerPlane: '', ownerId: '', leaseId: '', leaseUntil: '',
    handoffToPlane: '', handoffId: '', ambiguityReason: '',
    updatedAt: at, revision: 1,
  });
}

export function normalizeExecutionOwnershipV1(raw) {
  raw = obj(raw, 'ExecutionOwnershipV1');
  exact(raw, new Set(['schemaVersion','taskId','planId','nodeId','effectId','policyEnvelopeId','state','ownerPlane','ownerId','leaseId','leaseUntil','handoffToPlane','handoffId','ambiguityReason','updatedAt','revision']), 'ExecutionOwnershipV1');
  if (raw.schemaVersion !== EXECUTION_OWNERSHIP_VERSION) throw new Error('Unsupported ExecutionOwnershipV1 schemaVersion');
  if (typeof raw.state !== 'string' || raw.state !== raw.state.trim() || !STATES.has(raw.state)) throw new Error('ExecutionOwnershipV1 state is invalid');
  const state = raw.state;
  const ownerPlane = optionalPlane(raw.ownerPlane);
  const ownerId = optionalId(raw.ownerId, 'ownerId');
  const leaseId = optionalId(raw.leaseId, 'leaseId');
  const leaseUntil = optionalTs(raw.leaseUntil, 'leaseUntil');
  const handoffToPlane = optionalPlane(raw.handoffToPlane);
  const handoffId = optionalId(raw.handoffId, 'handoffId');
  const ambiguityReason = optionalBoundedText(raw.ambiguityReason, 'ambiguityReason');
  const owned = state === ExecutionOwnershipState.OWNED || state === ExecutionOwnershipState.HANDOFF_PENDING || state === ExecutionOwnershipState.RECONCILE;
  if (owned && (!ownerPlane || !ownerId || !leaseId || !leaseUntil)) throw new Error('owned execution state requires complete owner lease identity');
  if (!owned && (ownerPlane || ownerId || leaseId || leaseUntil)) throw new Error('unowned execution state cannot retain owner lease identity');
  if (state === ExecutionOwnershipState.HANDOFF_PENDING && (!handoffToPlane || !handoffId || handoffToPlane === ownerPlane)) throw new Error('handoff requires a distinct target plane and handoff identity');
  if (state !== ExecutionOwnershipState.HANDOFF_PENDING && (handoffToPlane || handoffId)) throw new Error('handoff metadata is only valid while HANDOFF_PENDING');
  if ((state === ExecutionOwnershipState.RECONCILE || state === ExecutionOwnershipState.MANUAL_REVIEW) !== Boolean(ambiguityReason)) throw new Error('ambiguity reason must exist exactly for reconciliation/manual review');
  const revision = raw.revision;
  if (typeof revision !== 'number' || !Number.isSafeInteger(revision) || Object.is(revision, -0) || revision < 1) throw new Error('ExecutionOwnershipV1 revision is invalid');
  return freeze({ schemaVersion: EXECUTION_OWNERSHIP_VERSION, taskId: id(raw.taskId,'taskId'), planId: id(raw.planId,'planId'), nodeId: id(raw.nodeId,'nodeId'), effectId: id(raw.effectId,'effectId'), policyEnvelopeId: id(raw.policyEnvelopeId,'policyEnvelopeId'), state, ownerPlane, ownerId, leaseId, leaseUntil, handoffToPlane, handoffId, ambiguityReason, updatedAt: ts(raw.updatedAt,'updatedAt'), revision });
}

function nextRevision(revision) {
  const value = revision + 1;
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new Error('ExecutionOwnershipV1 revision exceeds exact durable-state range');
  }
  return value;
}

function next(raw, patch, at) {
  const current = normalizeExecutionOwnershipV1(raw);
  const transitionAt = ts(at,'at');
  if (Date.parse(transitionAt) < Date.parse(current.updatedAt)) {
    throw new Error('execution ownership transition cannot predate current durable state');
  }
  return normalizeExecutionOwnershipV1({ ...current, ...patch, updatedAt: transitionAt, revision: nextRevision(current.revision) });
}

function assertLeaseDuration(at, leaseUntil) {
  const start = Date.parse(ts(at,'at')); const end = Date.parse(ts(leaseUntil,'leaseUntil'));
  if (end <= start || end - start > MAX_LEASE_MS) throw new Error('execution ownership lease duration is invalid');
}

function assertLeaseLive(current, at) {
  if (Date.parse(ts(at,'at')) > Date.parse(current.leaseUntil)) {
    throw new Error('execution ownership lease has expired and requires reconciliation');
  }
}

export function claimExecutionOwnershipV1(raw, { plane: requestedPlane, ownerId, leaseId, leaseUntil, at = new Date().toISOString() } = {}) {
  const current = normalizeExecutionOwnershipV1(raw);
  if (current.state !== ExecutionOwnershipState.AVAILABLE) throw new Error('execution effect is not available to claim');
  assertLeaseDuration(at, leaseUntil);
  return next(current, { state: ExecutionOwnershipState.OWNED, ownerPlane: plane(requestedPlane), ownerId: id(ownerId,'ownerId'), leaseId: id(leaseId,'leaseId'), leaseUntil: ts(leaseUntil,'leaseUntil') }, at);
}

export function requestExecutionHandoffV1(raw, { leaseId, toPlane, handoffId, at = new Date().toISOString() } = {}) {
  const current = normalizeExecutionOwnershipV1(raw);
  if (current.state !== ExecutionOwnershipState.OWNED || current.leaseId !== id(leaseId,'leaseId')) throw new Error('only the current execution owner may request handoff');
  assertLeaseLive(current, at);
  return next(current, { state: ExecutionOwnershipState.HANDOFF_PENDING, handoffToPlane: plane(toPlane), handoffId: id(handoffId,'handoffId') }, at);
}

export function acceptExecutionHandoffV1(raw, { handoffId, ownerId, leaseId, leaseUntil, at = new Date().toISOString() } = {}) {
  const current = normalizeExecutionOwnershipV1(raw);
  if (current.state !== ExecutionOwnershipState.HANDOFF_PENDING || current.handoffId !== id(handoffId,'handoffId')) throw new Error('execution handoff identity mismatch');
  assertLeaseLive(current, at);
  assertLeaseDuration(at, leaseUntil);
  return next(current, { state: ExecutionOwnershipState.OWNED, ownerPlane: current.handoffToPlane, ownerId: id(ownerId,'ownerId'), leaseId: id(leaseId,'leaseId'), leaseUntil: ts(leaseUntil,'leaseUntil'), handoffToPlane: '', handoffId: '' }, at);
}

export function recoverExpiredExecutionOwnershipV1(raw, { at = new Date().toISOString(), reason = 'owner lease expired before verified completion' } = {}) {
  const current = normalizeExecutionOwnershipV1(raw);
  if (![ExecutionOwnershipState.OWNED, ExecutionOwnershipState.HANDOFF_PENDING].includes(current.state)) throw new Error('execution ownership is not recoverable');
  if (Date.parse(ts(at,'at')) <= Date.parse(current.leaseUntil)) throw new Error('execution ownership lease has not expired');
  // Expiry alone can never prove that an external effect did not happen.
  // Every ambiguous expired attempt first enters RECONCILE and preserves the
  // original lease identity until a fresh canonical VerificationV1 resolves it.
  return next(current, { state: ExecutionOwnershipState.RECONCILE, handoffToPlane: '', handoffId: '', ambiguityReason: boundedText(reason,'reason') }, at);
}

export function resolveExecutionReconciliationV1(raw, options = {}) {
  const request = obj(options, 'Execution reconciliation request');
  exact(request, new Set(['leaseId', 'outcome', 'verification', 'at']), 'Execution reconciliation request');
  const current = normalizeExecutionOwnershipV1(raw);
  const leaseId = request.leaseId;
  const outcome = request.outcome;
  const at = request.at === undefined ? new Date().toISOString() : request.at;
  if (current.state !== ExecutionOwnershipState.RECONCILE || current.leaseId !== id(leaseId,'leaseId')) {
    throw new Error('reconciliation requires the preserved owner lease identity');
  }
  if (typeof outcome !== 'string' || outcome !== outcome.trim()) throw new Error('reconciliation outcome must use exact canonical text');
  const normalized = outcome;
  if (normalized === 'MANUAL_REVIEW') {
    return next(current, {
      state: ExecutionOwnershipState.MANUAL_REVIEW,
      ownerPlane: '',
      ownerId: '',
      leaseId: '',
      leaseUntil: '',
      ambiguityReason: current.ambiguityReason,
    }, at);
  }
  if (normalized === 'VERIFIED' || normalized === 'SAFE_RETRY') {
    // VerificationV1 normalization proves shape, not provenance. Until an
    // independently resolved canonical verifier record is available, caller-
    // supplied verification data cannot release or complete an ambiguous effect.
    throw new Error('trusted verifier provenance is required before automated reconciliation');
  }
  throw new Error('reconciliation outcome must be VERIFIED, SAFE_RETRY, or MANUAL_REVIEW');
}

export function verifyOwnedExecutionV1(raw, options = {}) {
  const request = obj(options, 'Execution owner verification request');
  exact(request, new Set(['leaseId', 'at']), 'Execution owner verification request');
  const current = normalizeExecutionOwnershipV1(raw);
  const leaseId = request.leaseId;
  const at = request.at === undefined ? new Date().toISOString() : request.at;
  if (current.state !== ExecutionOwnershipState.OWNED || current.leaseId !== id(leaseId,'leaseId')) {
    throw new Error('only the current execution owner may verify completion');
  }
  assertLeaseLive(current, at);
  // Ownership proves who may perform the effect, not who may independently
  // certify it.  Preserve this export for compatibility but never let an
  // effect owner mint canonical VERIFIED without resolved verifier provenance.
  throw new Error('canonical trusted verifier provenance is required before execution can be VERIFIED');
}

/**
 * Compatibility boundary for callers that previously supplied verifier-shaped
 * fields directly.  Verifier IDs, policy-envelope IDs and free-text evidence
 * supplied by the caller are assertions, not independently resolved proof.
 * Until the canonical verifier/evidence authority can supply provenance, this
 * function must keep the live owned effect fenced rather than mint VERIFIED.
 */
export function verifyExecutionByAuthorityV1(raw, options = {}) {
  const request = obj(options, 'Execution authority verification request');
  exact(
    request,
    new Set(['leaseId', 'verifierId', 'verificationAuthorityId', 'evidence', 'at']),
    'Execution authority verification request',
  );
  const current = normalizeExecutionOwnershipV1(raw);
  const leaseId = request.leaseId;
  const at = request.at === undefined ? new Date().toISOString() : request.at;
  if (current.state !== ExecutionOwnershipState.OWNED || current.leaseId !== id(leaseId,'leaseId')) {
    throw new Error('only the current execution lease may be independently verified');
  }
  assertLeaseLive(current, at);
  throw new Error('canonical trusted verifier provenance is required before execution can be VERIFIED');
}


/**
 * Completes one exact owned effect only from a canonical trusted verification
 * record. The resolver is the authority boundary; caller-shaped VerificationV1
 * data remains rejected by the compatibility functions above.
 */
export async function verifyExecutionWithTrustedRecordV1(raw, options = {}, dependencies = {}) {
  const current = normalizeExecutionOwnershipV1(raw);
  if (current.state !== ExecutionOwnershipState.OWNED) {
    throw new Error('trusted completion verification requires current OWNED execution');
  }
  const resolved = await resolveTrustedExecutionVerificationV1(
    current,
    options,
    dependencies,
    TrustedExecutionVerificationOutcome.EFFECT_VERIFIED,
  );
  const ownership = next(current, {
    state: ExecutionOwnershipState.VERIFIED,
    ownerPlane: '',
    ownerId: '',
    leaseId: '',
    leaseUntil: '',
    ambiguityReason: '',
  }, resolved.evaluatedAt);
  return freeze({
    ownership,
    trustedRecord: resolved.record,
    verificationProvenance: 'TRUSTED_CANONICAL_EXECUTION_VERIFICATION_RECORD_WITH_HASHED_ARTIFACT_REFS',
  });
}

/**
 * Releases an ambiguous expired effect for normal bounded re-admission only
 * when a trusted independent record verifies that the exact lease committed no
 * effect. This function never dispatches the retry.
 */
export async function authorizeExecutionSafeRetryWithTrustedRecordV1(raw, options = {}, dependencies = {}) {
  const current = normalizeExecutionOwnershipV1(raw);
  if (current.state !== ExecutionOwnershipState.RECONCILE) {
    throw new Error('trusted SAFE_RETRY requires RECONCILE execution ownership');
  }
  const resolved = await resolveTrustedExecutionVerificationV1(
    current,
    options,
    dependencies,
    TrustedExecutionVerificationOutcome.NO_EFFECT_VERIFIED,
  );
  const ownership = next(current, {
    state: ExecutionOwnershipState.AVAILABLE,
    ownerPlane: '',
    ownerId: '',
    leaseId: '',
    leaseUntil: '',
    ambiguityReason: '',
  }, resolved.evaluatedAt);
  return freeze({
    ownership,
    trustedRecord: resolved.record,
    verificationProvenance: 'TRUSTED_CANONICAL_NO_EFFECT_RECORD_WITH_HASHED_ARTIFACT_REFS',
  });
}
