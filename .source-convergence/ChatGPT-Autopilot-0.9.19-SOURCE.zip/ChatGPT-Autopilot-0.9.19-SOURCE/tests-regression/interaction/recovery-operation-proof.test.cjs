'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadAdapter() {
  const sourcePath = path.resolve(__dirname, '../../src/interaction/chatgpt-adapter.js');
  const source = fs.readFileSync(sourcePath, 'utf8');
  let clock = 0;
  class FakeDate extends Date {
    static now() { clock += 1000; return clock; }
  }
  class FakeEvent { constructor(type, init) { this.type = type; Object.assign(this, init); } }
  class FakeTextAreaElement {}
  class FakeInputElement {}
  const sandbox = {
    URL,
    Date: FakeDate,
    setTimeout,
    clearTimeout,
    Event: FakeEvent,
    InputEvent: FakeEvent,
    HTMLTextAreaElement: FakeTextAreaElement,
    HTMLInputElement: FakeInputElement,
    console,
    location: { href: 'https://chatgpt.com/c/abc' },
    getComputedStyle: () => ({ display: 'block', visibility: 'visible' })
  };
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: sourcePath });
  return sandbox.ChatGPTInteractionAdapter;
}

function request() {
  return {
    requestId: 'op-repeat-2',
    taskId: 'task-1',
    expectedUrl: 'https://chatgpt.com/c/abc',
    promptText: 'same recurring prompt',
    mode: 'VERIFY_AFTER_UNCERTAIN_SUBMIT'
  };
}

function fixture({ composerValue = '', previousMessages = [] } = {}) {
  const composer = {
    isConnected: true,
    hidden: false,
    disabled: false,
    tagName: 'TEXTAREA',
    value: composerValue,
    getAttribute(name) {
      if (name === 'aria-label') return 'Message';
      return null;
    },
    getBoundingClientRect() { return { width: 100, height: 20 }; },
    closest() { return null; }
  };
  const messages = previousMessages.map((text) => ({
    isConnected: true,
    hidden: false,
    disabled: false,
    innerText: text,
    getAttribute(name) { return name === 'data-message-author-role' ? 'user' : null; },
    getBoundingClientRect() { return { width: 100, height: 20 }; }
  }));
  const document = {
    body: { innerText: '' },
    querySelectorAll(selector) {
      if (selector === 'textarea, [contenteditable="true"], [role="textbox"], input[type="text"]') return [composer];
      if (selector === 'button, [role="button"]') return [];
      if (selector === '[role="dialog"], dialog') return [];
      if (selector === '[data-message-author-role="user"], [data-author="user"], article') return messages;
      return [];
    }
  };
  return { document };
}

test('old identical recurring prompt cannot prove current uncertain operation', async () => {
  const adapter = loadAdapter();
  const fx = fixture({ previousMessages: ['same recurring prompt'] });
  const result = await adapter.execute(request(), { document: fx.document });
  assert.equal(result.status, adapter.STATUS.SUBMISSION_UNCERTAIN);
  assert.equal(result.safeDiagnosticCode, 'RECOVERY_STALE_MATCH_UNPROVEN');
  assert.equal(result.submissionEvidence, 'HISTORY_MATCH_NOT_OPERATION_BOUND');
});

test('pending exact composer text outranks stale identical history', async () => {
  const adapter = loadAdapter();
  const fx = fixture({
    composerValue: 'same recurring prompt',
    previousMessages: ['same recurring prompt']
  });
  const result = await adapter.execute(request(), { document: fx.document });
  assert.equal(result.status, adapter.STATUS.SUBMISSION_UNCERTAIN);
  assert.equal(result.safeDiagnosticCode, 'RECOVERY_BASELINE_MISSING');
});

test('no matching composer/history remains uncertain rather than inventing proof', async () => {
  const adapter = loadAdapter();
  const fx = fixture({ previousMessages: ['different older prompt'] });
  const result = await adapter.execute(request(), { document: fx.document });
  assert.equal(result.status, adapter.STATUS.SUBMISSION_UNCERTAIN);
  assert.equal(result.safeDiagnosticCode, 'RECOVERY_UNCERTAIN');
  assert.equal(result.submissionEvidence, 'UNCERTAIN');
});
