const STATE = Object.freeze({
  RUNNING: 'ПРАЦЮЄ',
  COMPLETED: 'ЗАВЕРШЕНО',
  RECOVERING: 'ВІДНОВЛЮЄТЬСЯ',
  PAUSED: 'ПРИЗУПИНЕНО',
  STOPPED: 'ЗУПИНЕНО',
  ERROR: 'ПОМИЛКА',
  RATE_LIMITED: 'ТИМЧАСОВЕ ОБМЕЖЕННЯ',
  RETRY_WAIT: 'ОЧІКУВАННЯ ПОВТОРНОЇ СПРОБИ',
  MANUAL_REVIEW: 'ПОТРІБНА РУЧНА ПЕРЕВІРКА',
  SUBMISSION_UNCERTAIN: 'РЕЗУЛЬТАТ ВІДПРАВЛЕННЯ НЕВИЗНАЧЕНИЙ',
  IDLE: 'ОЧІКУЄ',
  BUSY: 'ЧАТ ЗАЙНЯТИЙ',
  READY: 'ГОТОВО',
  CHECKING: 'ПЕРЕВІРКА',
  INSERTING: 'ВСТАВЛЕННЯ',
  INSERTED: 'ВСТАВЛЕНО',
  PRE_SEND_WAIT: 'ОЧІКУВАННЯ ПЕРЕД ВІДПРАВЛЕННЯМ',
  SUBMITTING: 'ВІДПРАВЛЕННЯ',
  SENT_VERIFIED: 'ВІДПРАВЛЕННЯ ПІДТВЕРДЖЕНО',
  AMBIGUOUS: 'НЕВИЗНАЧЕНИЙ РЕЗУЛЬТАТ',
  FAILED_SAFE: 'БЕЗПЕЧНО ЗУПИНЕНО',
  NONE: 'НЕМАЄ',
  UNKNOWN: 'НЕВІДОМО',
  TEMPORARY_ERROR: 'ТИМЧАСОВА ПОМИЛКА',
  AUTH_REQUIRED: 'ПОТРІБЕН ВХІД',
  UNKNOWN_UI: 'НЕВІДОМИЙ СТАН ІНТЕРФЕЙСУ',
  MANUAL_REVIEW_REQUIRED: 'ПОТРІБНА РУЧНА ПЕРЕВІРКА',
  INSERTION_NOT_PROVEN: 'НЕ ВДАЛОСЯ ПІДТВЕРДИТИ ВСТАВЛЕННЯ ПРОМПТУ',
  COMPOSER_CONTAINS_OTHER_CONTENT: 'У ПОЛІ ВВЕДЕННЯ Є ІНШИЙ ТЕКСТ',
  COMPOSER_AMBIGUOUS: 'ЗНАЙДЕНО КІЛЬКА МОЖЛИВИХ ПОЛІВ ВВЕДЕННЯ',
  PENDING_PROMPT_MISMATCH_PRE_SEND: 'ТЕКСТ У ПОЛІ ВВЕДЕННЯ ЗМІНИВСЯ ПЕРЕД ВІДПРАВЛЕННЯМ',
  PROMPT_CHANGED_AT_SUBMIT_BOUNDARY: 'ТЕКСТ У ПОЛІ ВВЕДЕННЯ ЗМІНИВСЯ БЕЗПОСЕРЕДНЬО ПЕРЕД ВІДПРАВЛЕННЯМ',
  UNKNOWN_OR_SECURITY_DIALOG: 'ВІДКРИТО НЕВІДОМЕ АБО БЕЗПЕКОВЕ ДІАЛОГОВЕ ВІКНО',
  SEND_ACK_TIMEOUT: 'НАДСИЛАННЯ НЕ ПІДТВЕРДЖЕНО; ДОСТУПНІ ДІЇ ВІДНОВЛЕННЯ',
  EXISTING_DRAFT_SYNC_NOT_PROVEN: 'НЕ ВДАЛОСЯ СИНХРОНІЗУВАТИ НАЯВНИЙ ПРОМПТ ІЗ РЕДАКТОРОМ',
  UNRECOGNIZED_DIALOG: 'ВІДКРИТО НЕРОЗПІЗНАНЕ ДІАЛОГОВЕ ВІКНО'
});

const EXACT = new Map([
  ['ChatGPT Autopilot', 'ChatGPT Автопілот'],
  ['Ready.', 'Готово.'],
  ['Master pause', 'Призупинити все'],
  ['Resume after master pause', 'Продовжити все'],
  ['Session navigation', 'Навігація сеансами'],
  ['Sessions', 'Сеанси'],
  ['Create session', 'Створити сеанс'],
  ['Keyboard and startup behavior', 'Клавіатура та поведінка після запуску'],
  ['Use Tab and Shift+Tab to move, Enter or Space to activate buttons, and Space to change checkboxes or radio buttons.', 'Для переходу між елементами використовуйте Tab і Shift+Tab. Для натискання кнопок — Enter або Пробіл, для прапорців і перемикачів — Пробіл.'],
  ['Checking the Open dashboard shortcut.', 'Перевірка комбінації для відкриття панелі.'],
  ['If the shortcut is not assigned or you want to change it, open chrome://extensions/shortcuts.', 'Якщо комбінацію не призначено або ви хочете її змінити, відкрийте chrome://extensions/shortcuts.'],
  ['The Open dashboard shortcut is unavailable in this browser.', 'У цьому браузері комбінація для відкриття панелі недоступна.'],
  ['The Open dashboard shortcut is not assigned. Assign it in chrome://extensions/shortcuts.', 'Комбінацію для відкриття панелі не призначено. Призначте її на сторінці chrome://extensions/shortcuts.'],
  ['Could not read the Open dashboard shortcut. Check chrome://extensions/shortcuts.', 'Не вдалося прочитати комбінацію для відкриття панелі. Перевірте chrome://extensions/shortcuts.'],
  ['Sessions left RUNNING or RECOVERING resume automatically when Chrome starts. PAUSED and STOPPED Sessions do not auto-resume.', 'Запущені сеанси та сеанси у відновленні автоматично продовжують роботу після запуску Chrome. Призупинені та зупинені сеанси автоматично не запускаються.'],
  ['Rate-limit recovery', 'Відновлення після обмеження запитів'],
  ['Fallback pause if “Too many requests” remains, minutes', 'Резервна пауза, якщо «Забагато запитів» не зникло, хвилини'],
  ['The extension first presses “Understood” and immediately continues the same task in the same tab. This pause is used only if the blocking notice remains or returns after acknowledgement.', 'Спочатку розширення натискає «Зрозуміло» й одразу продовжує те саме завдання в тій самій вкладці. Ця пауза застосовується лише якщо повідомлення не зникло або знову повернулося після підтвердження.'],
  ['Save fallback pause', 'Зберегти резервну паузу'],
  ['Loading fallback pause.', 'Завантаження резервної паузи.'],
  ['Configuration file', 'Файл налаштувань'],
  ['Keep the extension installed. Give the JSON template to an AI or edit it elsewhere, then import the completed file here. Import changes only Sessions named by stable ids in the file; unrelated Sessions remain untouched.', 'Залиште розширення встановленим. Передайте шаблон JSON штучному інтелекту або заповніть його в іншому місці, а потім імпортуйте готовий файл тут. Імпорт змінює лише сеанси зі стабільними ідентифікаторами, указаними у файлі; інші сеанси не змінюються.'],
  ['Download blank configuration template', 'Завантажити порожній шаблон налаштувань'],
  ['Choose configuration JSON file', 'Вибрати JSON-файл налаштувань'],
  ['No configuration file selected.', 'Файл налаштувань не вибрано.'],
  ['Import without starting (setup only)', 'Імпортувати БЕЗ ЗАПУСКУ (лише налаштувати)'],
  ['Import and START ALL requested Sessions', 'Імпортувати + ЗАПУСТИТИ ВСІ позначені сеанси'],
  ['Export current Sessions to JSON', 'Експортувати поточні сеанси у JSON'],
  ['Session', 'Сеанс'],
  ['Configuration errors', 'Помилки налаштування'],
  ['Configuration', 'Налаштування'],
  ['Session name', 'Назва сеансу'],
  ['Task configuration mode', 'Режим налаштування завдань'],
  ['One ChatGPT link + one shared prompt', 'Одне посилання ChatGPT + один спільний промпт'],
  ['One ChatGPT link + different prompts', 'Одне посилання ChatGPT + різні промпти'],
  ['Different ChatGPT links + one shared prompt', 'Різні посилання ChatGPT + один спільний промпт'],
  ['Different ChatGPT links + different prompts', 'Різні посилання ChatGPT + різні промпти'],
  ['ChatGPT link used for every task', 'Посилання ChatGPT для всіх завдань'],
  ['Shared prompt for every task', 'Спільний промпт для всіх завдань'],
  ['Optional default for empty prompt editors', 'Необов’язковий промпт за замовчуванням для порожніх редакторів'],
  ['Fill empty prompt editors with this text', 'Заповнити порожні редактори цим текстом'],
  ['Tasks / cycles', 'Завдання / цикли'],
  ['Number of tasks / cycles', 'Кількість завдань / циклів'],
  ['Use the number spinner or type a value from 1 to 1000. Editors below are added or removed automatically.', 'Виберіть стрілками або введіть число від 1 до 1000. Редактори нижче додаються або прибираються автоматично.'],
  ['Optional shortcut for modes with different links. Paste up to 1000 ChatGPT links; recognized links resize the task list automatically.', 'Необов’язкове масове вставлення для режимів із різними посиланнями. Можна вставити до 1000 посилань ChatGPT; список завдань змінить розмір автоматично.'],
  ['Prompt mode', 'Режим промптів'],
  ['One shared prompt for all tasks', 'Один спільний промпт для всіх завдань'],
  ['Unique prompt for each task', 'Окремий промпт для кожного завдання'],
  ['Shared prompt for all enabled tasks', 'Спільний промпт для всіх увімкнених завдань'],
  ['Default prompt for empty task prompts', 'Промпт за замовчуванням для порожніх завдань'],
  ['Apply default prompt to empty tasks', 'Застосувати промпт за замовчуванням до порожніх завдань'],
  ['Run mode', 'Режим роботи'],
  ['One pass', 'Один прохід'],
  ['Continuous monitor', 'Постійна робота по колу'],
  ['Tasks', 'Завдання'],
  ['Bulk ChatGPT links', 'Масове додавання посилань ChatGPT'],
  ['Paste up to 50 ChatGPT links. One link per line is recommended; numbered lists and whitespace-separated links are also recognized. Duplicates are ignored.', 'Вставте до 50 посилань ChatGPT. Рекомендовано одне посилання в кожному рядку; також розпізнаються нумеровані списки та посилання, розділені пробілами. Дублікати ігноруються.'],
  ['Add recognized links', 'Додати розпізнані посилання'],
  ['Replace task links with recognized links', 'Замінити посилання завдань розпізнаними'],
  ['No bulk link operation has been run.', 'Масову операцію з посиланнями ще не виконували.'],
  ['Add task', 'Додати завдання'],
  ['Up to 50 tasks per session.', 'До 50 завдань у кожному сеансі.'],
  ['Timing and behavior', 'Час і поведінка'],
  ['Minimum interval between actual sends, minutes', 'Мінімальний інтервал між фактичними відправленнями, хвилини'],
  ['Busy-chat checks do not consume this interval.', 'Перевірка зайнятого чату не використовує цей інтервал.'],
  ['Delay after prompt insertion before Send, seconds', 'Затримка після вставлення промпту перед відправленням, секунди'],
  ['Delay before checking the next task when current chat is busy, seconds', 'Затримка перед перевіркою наступного завдання, якщо поточний чат зайнятий, секунди'],
  ['Retry/backoff wait', 'Очікування перед повторною спробою'],
  ['Retry/backoff unit', 'Одиниця часу очікування'],
  ['Seconds', 'Секунди'],
  ['Minutes', 'Хвилини'],
  ['Used only when the exact Too many requests notice remains or returns after acknowledgement. The Session retries automatically when the saved wait expires.', 'Використовується лише якщо точне повідомлення «Забагато запитів» не зникло або повернулося після підтвердження. Коли заданий час мине, сеанс автоматично повторить спробу.'],
  ['Retry policy', 'Політика повторних спроб'],
  ['Unattended automatic retries (recommended)', 'Безнаглядні автоматичні повтори (рекомендовано)'],
  ['Manual review after temporary failure', 'Ручна перевірка після тимчасової помилки'],
  ['Busy chat behavior', 'Поведінка, коли чат зайнятий'],
  ['Skip immediately to next enabled task', 'Одразу перейти до наступного увімкненого завдання'],
  ['Tab strategy', 'Режим вкладок'],
  ['Keep task tabs open', 'Тримати вкладки завдань відкритими'],
  ['Use one worker tab for this session', 'Використовувати одну робочу вкладку для цього сеансу'],
  ['Open and close per task', 'Відкривати й закривати вкладку для кожного завдання'],
  ['Controls', 'Керування'],
  ['Save session', 'Зберегти сеанс'],
  ['Start', 'Запустити'],
  ['Pause', 'Призупинити'],
  ['Resume', 'Продовжити'],
  ['Stop', 'Зупинити'],
  ['No unsaved draft changes.', 'Незбережених змін немає.'],
  ['Unsaved draft restored from this browser.', 'Незбережену чернетку відновлено з цього браузера.'],
  ['Unsaved changes are protected locally in this browser.', 'Незбережені зміни локально захищено в цьому браузері.'],
  ['No runtime command has been issued.', 'Команди керування ще не виконувалися.'],
  ['Status', 'Стан'],
  ['Log', 'Журнал'],
  ['Core retains a bounded session log.', 'Програма зберігає обмежений журнал подій сеансу.'],
  ['Core retains a bounded session log. The options page shows only the newest 100 entries to stay responsive.', 'Програма зберігає обмежений журнал подій сеансу. На сторінці налаштувань показано лише 100 найновіших записів для стабільної роботи.'],
  ['0 Core log entries shown.', 'Показано 0 записів журналу.'],
  ['Session log', 'Журнал сеансу'],
  ['Clear log', 'Очистити журнал'],
  ['No session selected', 'Сеанс не вибрано'],
  ['Create or open a session to configure automation.', 'Створіть або відкрийте сеанс, щоб налаштувати автоматизацію.'],
  ['Delete session?', 'Видалити сеанс?'],
  ['This removes the selected session configuration.', 'Буде видалено налаштування вибраного сеансу.'],
  ['Delete session', 'Видалити сеанс'],
  ['Cancel', 'Скасувати'],
  ['Not available', 'Немає даних'],
  ['New session', 'Новий сеанс'],
  ['Unnamed session', 'Сеанс без назви'],
  ['Connected to Core.', 'З’єднання з ядром встановлено.'],
  ['Rename', 'Перейменувати'],
  ['Duplicate', 'Дублювати'],
  ['Delete', 'Видалити'],
  ['Task removed.', 'Завдання видалено.'],
  ['No valid ChatGPT links were recognized.', 'Не розпізнано жодного коректного посилання ChatGPT.'],
  ['Session name is required.', 'Вкажіть назву сеансу.'],
  ['Add at least one task.', 'Додайте щонайменше одне завдання.'],
  ['Shared prompt is required.', 'Вкажіть спільний промпт.'],
  ['Minimum send interval must be at least 1 minute.', 'Мінімальний інтервал між відправленнями має бути не менше 1 хвилини.'],
  ['Pre-send delay must be between 1 and 30 seconds.', 'Затримка перед відправленням має бути від 1 до 30 секунд.'],
  ['Busy-check delay must be between 1 and 30 seconds.', 'Затримка перевірки зайнятого чату має бути від 1 до 30 секунд.'],
  ['Retry backoff must be between 5 seconds and 60 minutes.', 'Очікування перед повторною спробою має бути від 5 секунд до 60 хвилин.'],
  ['Fix these configuration errors', 'Виправте ці помилки налаштування'],
  ['Session saved.', 'Сеанс збережено.'],
  ['Session created.', 'Сеанс створено.'],
  ['Edit the session name, then save.', 'Змініть назву сеансу, потім збережіть.'],
  ['Session duplicated.', 'Сеанс продубльовано.'],
  ['Session deleted.', 'Сеанс видалено.'],
  ['Shared prompt mode selected.', 'Вибрано режим спільного промпту.'],
  ['Unique prompt mode selected.', 'Вибрано режим окремих промптів.'],
  ['Session state', 'Стан сеансу'],
  ['Successfully sent', 'Успішно надіслано'],
  ['Completed tasks', 'Виконано завдань'],
  ['Remaining tasks', 'Залишилось завдань'],
  ['Completed time', 'Час завершення'],
  ['Current task', 'Поточне завдання'],
  ['Current task status', 'Стан поточного завдання'],
  ['Operation phase', 'Етап операції'],
  ['Last action', 'Остання дія'],
  ['Last action time', 'Час останньої дії'],
  ['Last successful send', 'Останнє успішне відправлення'],
  ['Next allowed Send', 'Наступне дозволене відправлення'],
  ['Retry or backoff until', 'Повторна спроба не раніше'],
  ['Manual review reason', 'Причина ручної перевірки'],
  ['Enabled tasks', 'Увімкнені завдання'],
  ['Last error', 'Остання помилка'],
  ['None', 'Немає'],
  ['Core runtime is not available yet.', 'Ядро програми ще недоступне.'],
  ['Core command failed.', 'Не вдалося виконати команду ядра.'],
  ['Core returned an unexpected master-pause state.', 'Ядро повернуло неочікуваний стан загального призупинення.']
]);

const RUNTIME = [
  ['Session configuration saved', 'Налаштування сеансу збережено'],
  ['Session configuration imported from portable profile', 'Налаштування сеансу імпортовано з переносного профілю'],
  ['Session started after confirmed portable profile import', 'Сеанс запущено після підтвердженого імпорту переносного профілю'],
  ['Session created', 'Сеанс створено'],
  ['Session duplicated', 'Сеанс продубльовано'],
  ['Session started; global pause cleared by explicit Start', 'Сеанс запущено; загальну паузу скасовано явною командою запуску'],
  ['Session resumed; global pause cleared by explicit Resume', 'Сеанс продовжено; загальну паузу скасовано явною командою продовження'],
  ['Master pause cleared by explicit session action; session remains paused unless explicitly started or resumed', 'Загальну паузу скасовано явною дією з сеансом; цей сеанс залишається призупиненим, доки його явно не запустять або не продовжать'],
  ['Session started', 'Сеанс запущено'],
  ['Session paused by master pause', 'Сеанс призупинено загальною паузою'],
  ['Session paused', 'Сеанс призупинено'],
  ['Session resumed into recovery', 'Сеанс продовжено в режимі відновлення'],
  ['Session resumed after master pause', 'Сеанс продовжено після загальної паузи'],
  ['Session resumed', 'Сеанс продовжено'],
  ['Session stopped; unresolved operation preserved', 'Сеанс зупинено; дані незавершеної операції збережено'],
  ['Session stopped', 'Сеанс зупинено'],
  ['Session completed all enabled one-pass tasks', 'Сеанс завершено: усі увімкнені завдання одного проходу виконано'],
  ['Session remains paused for manual review after master resume', 'Сеанс залишається призупиненим: потрібна ручна перевірка'],
  ['Another active or unresolved session already owns one of these ChatGPT conversations', 'Інший активний або незавершений сеанс уже використовує один із цих чатів ChatGPT'],
  ['Resolve the uncertain send operation before starting', 'Спочатку розв’яжіть невизначений результат попереднього відправлення'],
  ['Resolve the uncertain send operation before duplicating', 'Спочатку розв’яжіть невизначений результат попереднього відправлення'],
  ['Resolve manual review before resuming', 'Перед продовженням завершіть ручну перевірку'],
  ['Enable at least one task before starting', 'Перед запуском увімкніть щонайменше одне завдання'],
  ['The same ChatGPT conversation cannot appear twice in one active session', 'Один і той самий чат ChatGPT не може двічі використовуватися в одному активному сеансі'],
  ['Session is already active', 'Сеанс уже активний'],
  ['Only an active session can be paused', 'Призупинити можна лише активний сеанс'],
  ['Only a paused session can be resumed', 'Продовжити можна лише призупинений сеанс'],
  ['Pause or stop the session and resolve uncertain work before deleting', 'Перед видаленням призупиніть або зупиніть активний сеанс і розв’яжіть невизначене надсилання'],
  ['Profile send arbiter is busy', 'Механізм черги відправлень профілю зайнятий'],
  ['Automatic execution is unavailable', 'Автоматичне виконання недоступне'],
  ['Resume the extension before importing with automatic start', 'Перед імпортом з автоматичним запуском продовжте роботу розширення'],
  ['Automatic execution temporarily unavailable; retry scheduled.', 'Автоматичне виконання тимчасово недоступне; повторну спробу заплановано.'],
  ['Diagnostic:', 'Діагностика:'],
  ['Submission outcome uncertain; no resend scheduled.', 'Результат відправлення невизначений; повторне відправлення не заплановано.'],
  ['Insertion outcome was not confirmed; a safe retry was scheduled.', 'Результат вставлення не підтверджено; заплановано безпечну повторну спробу.'],
  ['Pre-submit operation was interrupted; a safe retry was scheduled.', 'Операцію перед відправленням перервано; заплановано безпечну повторну спробу.'],
  ['Interrupted pre-submit operation failed safe; retry scheduled.', 'Перервану операцію перед відправленням безпечно зупинено; повторну спробу заплановано.'],
  ['Interaction transport failed safely', 'Взаємодію з вкладкою безпечно зупинено через помилку'],
  ['Chat interaction failed safely. No result was recorded as sent.', 'Взаємодію з ChatGPT безпечно зупинено. Відправлення не зараховано як успішне.'],
  ['Stored state is corrupt', 'Збережений стан пошкоджено'],
  ['Stored state has an invalid schema version', 'Збережений стан має некоректну версію структури'],
  ['State was created by a newer extension version', 'Стан створено новішою версією розширення'],
  ['Session not found', 'Сеанс не знайдено'],
  ['Task not found', 'Завдання не знайдено'],
  ['Operation not found', 'Операцію не знайдено'],
  ['Outstanding operation exists', 'Існує незавершена операція'],
  ['No operation', 'Немає операції']
];

function actionLabel(value) {
  return ({
    Start: 'Запуск', Pause: 'Призупинення', Resume: 'Продовження', Stop: 'Зупинення',
    'Clear log': 'Очищення журналу', 'master pause': 'загальне призупинення', 'master resume': 'загальне продовження'
  })[value] || value;
}

function runtimeText(value) {
  let text = String(value ?? '');
  if (STATE[text]) return STATE[text];
  for (const [source, target] of RUNTIME) text = text.replaceAll(source, target);
  for (const [source, target] of Object.entries(STATE)) text = text.replaceAll(source, target);
  return text;
}

export function translateText(value) {
  const input = String(value ?? '');
  const leading = input.match(/^\s*/)?.[0] ?? '';
  const trailing = input.match(/\s*$/)?.[0] ?? '';
  const text = input.trim();
  if (!text) return input;
  if (EXACT.has(text)) return `${leading}${EXACT.get(text)}${trailing}`;
  if (STATE[text]) return `${leading}${STATE[text]}${trailing}`;

  let m;
  if ((m = text.match(/^Open session (.+)$/))) return `${leading}Відкрити сеанс ${m[1]}${trailing}`;
  if ((m = text.match(/^Rename session (.+)$/))) return `${leading}Перейменувати сеанс ${m[1]}${trailing}`;
  if ((m = text.match(/^Duplicate session (.+)$/))) return `${leading}Дублювати сеанс ${m[1]}${trailing}`;
  if ((m = text.match(/^Delete session (.+)\. This removes the selected session configuration\.$/))) return `${leading}Видалити сеанс «${m[1]}». Буде видалено його налаштування.${trailing}`;
  if ((m = text.match(/^Delete session (.+)$/))) return `${leading}Видалити сеанс ${m[1]}${trailing}`;
  if ((m = text.match(/^Session: (.+)$/))) return `${leading}Сеанс: ${m[1]}${trailing}`;
  if ((m = text.match(/^State: ([A-Z_]+)\.$/))) return `${leading}Стан: ${STATE[m[1]] || m[1]}.${trailing}`;
  if ((m = text.match(/^(\d+) enabled tasks\.$/))) return `${leading}Увімкнених завдань: ${m[1]}.${trailing}`;
  if ((m = text.match(/^Successfully sent: (\d+)\. Completed: (\d+)\/(\d+)\. Remaining: (\d+)\.$/))) return `${leading}Успішно надіслано: ${m[1]}. Виконано: ${m[2]}/${m[3]}. Залишилось: ${m[4]}.${trailing}`;
  if ((m = text.match(/^Sessions: (\d+)\. Running: (\d+)\. Completed: (\d+)\. Paused: (\d+)\. Errors: (\d+)\. Successfully sent total: (\d+)\.$/))) return `${leading}Сеансів: ${m[1]}. Працює: ${m[2]}. Завершено: ${m[3]}. Призупинено: ${m[4]}. Помилок: ${m[5]}. Успішно надіслано загалом: ${m[6]}.${trailing}`;
  if ((m = text.match(/^Open dashboard shortcut: (.+)\.$/))) return `${leading}Комбінація для відкриття панелі: ${m[1]}.${trailing}`;
  if ((m = text.match(/^Current fallback rate-limit pause: (\d+) minutes?\.$/))) return `${leading}Поточна резервна пауза після обмеження: ${m[1]} хв.${trailing}`;
  if ((m = text.match(/^Saved fallback: if “Too many requests” remains after acknowledgement, this Chrome profile waits (\d+) minutes? and then retries automatically\.$/))) return `${leading}Збережено резервну паузу: якщо «Забагато запитів» лишається після підтвердження, цей Chrome-профіль чекає ${m[1]} хв і автоматично повторює спробу.${trailing}`;
  if ((m = text.match(/^Could not load fallback rate-limit pause: (.+)$/))) return `${leading}Не вдалося завантажити паузу після обмеження: ${runtimeText(m[1])}${trailing}`;
  if ((m = text.match(/^Could not save fallback rate-limit pause: (.+)$/))) return `${leading}Не вдалося зберегти паузу після обмеження: ${runtimeText(m[1])}${trailing}`;

  if ((m = text.match(/^Task (\d+) URL is required\.$/))) return `${leading}Для завдання ${m[1]} потрібно вказати посилання.${trailing}`;
  if ((m = text.match(/^Task (\d+) must use a valid https:\/\/chatgpt\.com URL\.$/))) return `${leading}Для завдання ${m[1]} потрібно вказати коректне посилання https://chatgpt.com.${trailing}`;
  if ((m = text.match(/^Prompt for Task (\d+) is required(?: in unique mode)?\.$/))) return `${leading}У режимі окремих промптів для завдання ${m[1]} потрібно вказати промпт.${trailing}`;
  if ((m = text.match(/^Prompt for Task (\d+)$/))) return `${leading}Промпт для завдання ${m[1]}${trailing}`;
  if ((m = text.match(/^Remove Task (\d+)$/))) return `${leading}Видалити завдання ${m[1]}${trailing}`;
  if ((m = text.match(/^Task (\d+) added\.$/))) return `${leading}Додано завдання ${m[1]}.${trailing}`;
  if ((m = text.match(/^Task (\d+) enabled$/))) return `${leading}Завдання ${m[1]} увімкнено${trailing}`;
  if ((m = text.match(/^Task (\d+) label, optional$/))) return `${leading}Завдання ${m[1]}: назва, необов’язково${trailing}`;
  if ((m = text.match(/^Task (\d+) ChatGPT URL$/))) return `${leading}Завдання ${m[1]}: посилання ChatGPT${trailing}`;
  if ((m = text.match(/^Task (\d+)( — .+)?$/))) return `${leading}Завдання ${m[1]}${m[2] || ''}${trailing}`;

  if ((m = text.match(/^Task limit reached: 50\.$/))) return `${leading}Досягнуто межі: 50 завдань.${trailing}`;
  if ((m = text.match(/^Up to 50 tasks per session\. (\d+) configured\.$/))) return `${leading}До 50 завдань у сеансі. Налаштовано: ${m[1]}.${trailing}`;
  if ((m = text.match(/^(\d+) task\(s\) will use the same ChatGPT link and the same prompt\. No per-task editors are needed\.$/))) return `${leading}${m[1]} завдань/циклів використовуватимуть одне посилання ChatGPT і один промпт. Окремі редактори не потрібні.${trailing}`;
  if ((m = text.match(/^(\d+) task editor(?:s)? configured automatically\.$/))) return `${leading}Автоматично налаштовано редакторів завдань: ${m[1]}.${trailing}`;
  if ((m = text.match(/^(\d+) tasks? configured\.$/))) return `${leading}Налаштовано завдань/циклів: ${m[1]}.${trailing}`;
  if ((m = text.match(/^(\d+) configuration errors?\.$/))) return `${leading}Помилок налаштування: ${m[1]}.${trailing}`;
  if ((m = text.match(/^(\d+) Core log entr(?:y|ies) shown\.$/))) return `${leading}Показано записів журналу: ${m[1]}.${trailing}`;
  if ((m = text.match(/^(\d+) of (\d+) Core log entr(?:y|ies) shown\.$/))) return `${leading}Показано ${m[1]} із ${m[2]} записів журналу.${trailing}`;
  if ((m = text.match(/^(\d+) unique ChatGPT link\(s\) recognized; (\d+) new task\(s\) created\.(?: (\d+) link\(s\) did not fit the (?:50|1000)-task limit\.)?$/))) {
    const truncated = m[3] ? ` Не вмістилося через обмеження у 1000 завдань: ${m[3]}.` : '';
    return `${leading}Розпізнано унікальних посилань ChatGPT: ${m[1]}; створено нових завдань: ${m[2]}.${truncated}${trailing}`;
  }
  if ((m = text.match(/^Profile (.+): (\d+) Session\(s\), (\d+) Task\(s\), (\d+) marked for automatic start\.$/))) return `${leading}Профіль ${m[1]}: сеансів — ${m[2]}, завдань — ${m[3]}, позначено для автоматичного запуску — ${m[4]}.${trailing}`;
  if ((m = text.match(/^Portable configuration imported: (\d+) Session\(s\)\. (\d+) Session\(s\) started\.$/))) return `${leading}Переносні налаштування імпортовано: сеансів — ${m[1]}. Запущено сеансів — ${m[2]}.${trailing}`;
  if ((m = text.match(/^Exported (\d+) Session\(s\) to JSON\.$/))) return `${leading}Експортовано сеансів у JSON: ${m[1]}.${trailing}`;
  if ((m = text.match(/^Configuration file error: (.+)$/))) return `${leading}Помилка файла налаштувань: ${runtimeText(m[1])}${trailing}`;
  if ((m = text.match(/^Import failed: (.+)$/))) return `${leading}Імпорт не виконано: ${runtimeText(m[1])}${trailing}`;
  if ((m = text.match(/^Export failed: (.+)$/))) return `${leading}Експорт не виконано: ${runtimeText(m[1])}${trailing}`;
  if ((m = text.match(/^Core acknowledged (.+)\. Current state: ([A-Z_]+)\.$/))) return `${leading}Команду «${actionLabel(m[1])}» виконано. Поточний стан: ${STATE[m[2]] || m[2]}.${trailing}`;
  if ((m = text.match(/^Core acknowledged (.+)\.$/))) return `${leading}Команду «${actionLabel(m[1])}» виконано.${trailing}`;
  if ((m = text.match(/^Command failed: (.+)$/))) return `${leading}Не вдалося виконати команду: ${runtimeText(m[1])}${trailing}`;
  if ((m = text.match(/^Retry\/backoff unit changed to (minutes|seconds)\. Current wait is ([0-9.]+) (minutes|seconds)\.$/))) return `${leading}Одиницю часу змінено на ${m[1] === 'minutes' ? 'хвилини' : 'секунди'}. Поточне очікування: ${m[2]}.${trailing}`;
  if ((m = text.match(/^Default prompt applied to (\d+) empty tasks?\.$/))) return `${leading}Промпт за замовчуванням застосовано до порожніх завдань: ${m[1]}.${trailing}`;

  return `${leading}${runtimeText(text)}${trailing}`;
}

function translateElement(element) {
  for (const attr of ['aria-label', 'title']) {
    if (!element.hasAttribute(attr)) continue;
    const oldValue = element.getAttribute(attr);
    const newValue = translateText(oldValue);
    if (oldValue !== newValue) element.setAttribute(attr, newValue);
  }
}

function translateNode(node) {
  if (node.nodeType === Node.TEXT_NODE) {
    const parent = node.parentElement;
    if (!parent || ['SCRIPT', 'STYLE', 'TEXTAREA'].includes(parent.tagName)) return;
    const next = translateText(node.nodeValue);
    if (next !== node.nodeValue) node.nodeValue = next;
    return;
  }
  if (node.nodeType !== Node.ELEMENT_NODE) return;
  translateElement(node);
  for (const child of node.childNodes) translateNode(child);
}

export function installUkrainianUi(doc = document) {
  doc.documentElement.lang = 'uk';
  doc.title = 'ChatGPT Автопілот';
  translateNode(doc.body);
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === 'characterData') translateNode(mutation.target);
      else if (mutation.type === 'childList') for (const node of mutation.addedNodes) translateNode(node);
      else if (mutation.type === 'attributes') translateElement(mutation.target);
    }
  });
  observer.observe(doc.body, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['aria-label', 'title']
  });
  return observer;
}

if (typeof document !== 'undefined' && document.body) installUkrainianUi(document);
