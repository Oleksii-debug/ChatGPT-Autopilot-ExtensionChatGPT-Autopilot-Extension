import gradio as gr
import wave
import numpy as np
from io import BytesIO
from huggingface_hub import hf_hub_download
from piper import PiperVoice


def synthesize_speech(text):
    model_path = hf_hub_download(
        repo_id="raphaelmerx/piper-voices",
        filename="tdt/tdt_TL/joao/medium/tdt_TL-joao-medium.onnx",
    )
    config_path = hf_hub_download(
        repo_id="raphaelmerx/piper-voices",
        filename="tdt/tdt_TL/joao/medium/tdt_TL-joao-medium.onnx.json",
    )
    voice = PiperVoice.load(model_path, config_path)

    # Create an in-memory buffer for the WAV file
    buffer = BytesIO()
    with wave.open(buffer, "wb") as wav_file:
        wav_file.setframerate(voice.config.sample_rate)
        wav_file.setsampwidth(2)  # 16-bit
        wav_file.setnchannels(1)  # mono

        # Synthesize speech
        voice.synthesize(text, wav_file)

    # Convert buffer to NumPy array for Gradio output
    buffer.seek(0)
    audio_data = np.frombuffer(buffer.read(), dtype=np.int16)

    # In Gradio 6, Audio with type="numpy" expects a tuple of (sample_rate, audio_array)
    return (voice.config.sample_rate, audio_data), None


# Using Gradio Blocks
# In Gradio 6, theme moved from Blocks() constructor to launch()
with gr.Blocks() as blocks:
    gr.Markdown("# Text to Speech Synthesizer")
    gr.Markdown("Enter text to synthesize it into speech using PiperVoice.")
    input_text = gr.Textbox(label="Input Text")
    output_audio = gr.Audio(label="Synthesized Speech", type="numpy")
    output_text = gr.Textbox(
        label="Output Text", visible=False
    )  # This is the new text output component
    submit_button = gr.Button("Synthesize")

    submit_button.click(
        synthesize_speech, inputs=input_text, outputs=[output_audio, output_text]
    )

# Run the app
blocks.launch(theme="base")
